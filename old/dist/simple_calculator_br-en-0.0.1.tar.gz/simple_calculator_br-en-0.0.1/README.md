# package_name

Description. 
The package simple_calculator is used to:
	- simple calc operation
	- sum, subtract, multiply or divide
	- just once type operator per time (+ | - | * | /)
	- eg.: 10+10+10+10 or 20-20-20-20 ...

## Installation

Use the package manager [pip](https://pip.pypa.io/en/stable/) to install package_name

```bash
pip install simple_calculator_br-en
```

## Author
Daniel Victor

## License
[MIT](https://choosealicense.com/licenses/mit/)